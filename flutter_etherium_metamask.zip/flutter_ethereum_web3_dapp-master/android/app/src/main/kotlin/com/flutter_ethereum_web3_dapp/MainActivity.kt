package com.flutter_ethereum_web3_dapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
